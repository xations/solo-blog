title: Java 数组
date: '2019-09-08 22:53:21'
updated: '2019-09-08 23:00:32'
tags: [Java, Array]
permalink: /articles/2019/09/08/1567954401582.html
---
![ash-edmonds-Koxa-GX_5zs-unsplash.jpg](https://i.loli.net/2019/09/08/ULgSROqVezM2t3r.jpg)

### 数组的定义

一系列对象或者基本数据类型，所有相同的类型都封装到一起，采用一个统一的标识符

 **Java 数组的本质是对象**

具有 Java 中其他对象的一些基本特点：封装了一些数据，可以调用方法。

如果有两个类 A 和 B，如果 B 继承（extends）了 A，那么 A[] 类型的引用就可以指向 B[] 类型的对象。

### java 数组与内存

数组对象（这里可以看成一个指针）存储在栈中。

数组元素存储在堆中。

如下图所示：只有当 JVM 执行 `new String[]` 时，才会在堆中开辟相应的内存区域。数组对象 array 可以视为一个指针，指向这块内存的存储地址。

![Untitled Diagram.png](https://i.loli.net/2019/09/08/HLPxkNpEAOWarvc.png)

### 声明数组

``` java
int[] arr1; // 推荐风格
int arr2[]; // 效果相同
```

### 创建数组

Java 语言使用 `new` 操作符来创建数组。有两种创建数组方式：

- 指定数组维度 
  - 为数组开辟指定大小的数组维度。
  - 如果数组元素是基础数据类型，会将每个元素设为默认值；如果是引用类型，元素值为 `null`。
- 不指定数组维度 
  - 用花括号中的实际元素初始化数组，数组大小与元素数相同。

```java
int[] array1 = new int[2]; // 指定数组维度
int[] array2 = new int[] { 1, 2 }; // 不指定数组维度
```

### 数组维度的形式

创建数组时，指定的数组维度可以有多种形式：

- 数组维度可以是整数、字符。
- 数组维度可以是整数型、字符型变量。
- 数组维度可以是计算结果为整数或字符的表达式。

### 数组维度的大小

**数组维度并非没有上限的，如果数值过大，编译时会报错。**

### 访问数组

**Java 中，可以通过在 [] 中指定下标，访问数组元素，下标位置从 0 开始。**

### 数组的引用

**Java 中，数组类型是一种引用类型**。

因此，它可以作为引用，被 Java 函数**作为函数入参或返回值**。

### 多维数组

多维数组可以看成是数组的数组，比如二维数组就是一个特殊的一维数组，其每一个元素都是一个一维数组。

### Arrays 类

Java 中，提供了一个很有用的数组工具类：Arrays。

它提供的主要操作有：

- `sort` - 排序
- `binarySearch` - 查找
- `equals` - 比较
- `fill` - 填充
- `asList` - 转列表
- `hash` - 哈希
- `toString` - 转字符串

### 部分代码

```java
package com.xation.dome01;

import java.util.Arrays;

public class ArraysTest001 {
    public static void main(String[] args) {
    int [] a = {9,8,7,2,3,4,1,0,6,5};
        Arrays.sort(a);
        printArray(a);
    }

    public static void printArray(int[] array){
        for (int i : array){
            System.out.print(i+" ");
        }
    }
}
```



```java
package com.xation.dome01;

import java.util.Arrays;

public class ArraysTest002 {
    public static void main(String[] args) {
        String[] a = {"a","A","B","b"};
        Arrays.sort(a); //字符串排序，先大写，后小写
        printArray(a);

    }

    public static void printArray(String[] array){
        for (String i : array){
            System.out.print(i+" ");
        }
    }
}

```

```java
package com.xation.dome01;

import java.util.Arrays;

public class ArraysTest003 {
    public static void main (String[] args) {
        String[] a = {"a","C","B","h"};
        Arrays.sort(a,String.CASE_INSENSITIVE_ORDER); //字符串严格排序，忽略大小写
        for (String i : a){
            System.out.print(i+" ");
        }
    }
}

```

```java
package com.xation.dome01;

import java.util.Arrays;
import java.util.Collections;

public class ArraysTest004 {
    public static void main (String[] args) {
        String[] a = {"B","A","a","b"};
        Arrays.sort(a, Collections.reverseOrder()); //字符串反向
        for (String i : a ) {
            System.out.print(i+" ");
        }
    }
}

```

```java
package com.xation.dome01;

import java.util.Arrays;
import java.util.Collections;

public class ArraysTest005 {
    public static void main (String[] args) {
        Integer[] a = {1,4,3,2,7,8,9,5,6,0}; //不能使用基本数据类型,使用包装类
        Arrays.sort(a, Collections.reverseOrder());
        for (int i : a) {
            System.out.print(i+" ");
        }
    }
}
```

```java
package com.xation.dome01;

import java.util.Arrays;
import java.util.Collections;

public class ArraysTest005 {
    public static void main (String[] args) {
        Integer[] a = {1,4,3,2,7,8,9,5,6,0}; //不能使用基本数据类型,使用包装类
        Arrays.sort(a, Collections.reverseOrder());
        for (int i : a) {
            System.out.print(i+" ");
        }
    }
}
```

```java
package com.xation.dome01;

import java.util.Arrays;
import java.util.Collections;

public class ArraysTest006 {
    public static void main (String[] args) {
        String[] a = {"d","a","b","C"};
        Arrays.sort(a,String.CASE_INSENSITIVE_ORDER);
        Collections.reverse(Arrays.asList(a)); //忽略大小写，反向排序
        for (String i : a) {
            System.out.print(i+" ");
        }
    }
}
```

```java
package com.xation.dome01;

import java.util.Arrays;

public class ArraysTest007 {
    public static void main (String[] args) {
        int[] a = {8,7,2,3,4,1,0,6,5};
        Arrays.sort(a,0,3); //数组a的下标从fromIndex到toIndex-1的元素排序
        for (int i : a ) {
            System.out.print(i+" ");
        }
    }
}
```

```java
package com.xation.dome01;

import java.util.Arrays;

public class ArraysTest008 {
    public static void main (String[] args) {
        int[] b = {03,25,27,99,67,78};
        System.out.print("原数组为：");
        for (int i : b){
            System.out.print(i+" ");
        }

        System.out.println();
        Arrays.sort(b);
        System.out.print("排序后为：");
        for (int i : b) {
            System.out.print(i+" ");
        }

        System.out.println();
        int index = Arrays.binarySearch(b,2);
        System.out.println("关键字2的返回值为："+index);

        index = Arrays.binarySearch(b,20);
        System.out.println("关键字20的返回值为："+index);

        index = Arrays.binarySearch(b,90);
        System.out.println("关键字90的返回值为："+index);

        index = Arrays.binarySearch(b,60);
        System.out.println("关键字60的返回值为："+index);

        index = Arrays.binarySearch(b,99);
        System.out.println("关键字99的返回值为："+index);

    }
}
```
