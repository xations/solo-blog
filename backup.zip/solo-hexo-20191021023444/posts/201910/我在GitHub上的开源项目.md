title: 我在 GitHub 上的开源项目
date: '2019-10-06 18:04:58'
updated: '2019-10-06 18:04:58'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [solo-blog](https://github.com/xations/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xations/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xations/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xations/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://amdyes.top`](https://amdyes.top "项目主页")</span>

菜鸟新人 - 他们忙着创造，我们忙着修复



---

### 2. [View](https://github.com/xations/View) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/xations/View/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/xations/View/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xations/View/network/members "分叉数")</span>

自定义View学习

