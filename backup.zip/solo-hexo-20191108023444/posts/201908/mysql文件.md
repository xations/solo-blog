title: ' mysql文件'
date: '2019-08-23 17:48:43'
updated: '2019-08-23 22:23:54'
tags: [MySQL]
permalink: /articles/2019/08/23/1566553723593.html
---
![caspar-camille-rubin-fPkvU7RDmCo-unsplash.jpg](https://i.loli.net/2019/08/23/26wx1JjTcRGbFdz.jpg)


  

#### 参数文件

  

告诉数据库实例启动时在那可以找到数据库文件，并且指定某些初始化参数，这些参数定义内存结构大小设置，介绍参数类型。

  

通过mysql —help|grep my.cnf查找

  

MySQL实例可以不需要配置文件，但是需要mysql架构。mysql架构中记录了该实例的访问权限。以文本方式进行存储。

  

show variables来查看也可以vim

  

##### 文件参数

  

read_buffer_size：（数据文件存储顺序）是MySQL读入缓冲区的大小，将对表进行顺序扫描的请求将分配一个读入缓冲区，MySQL会为它分配一段内存缓冲区，read_buffer_size变量控制这一缓冲区的大小，如果对表的顺序扫描非常频繁，并你认为频繁扫描进行的太慢，可以通过增加该变量值以及内存缓冲区大小提高其性能。

  

#### 日志文件

  

用来记录MySQL实例对某种条件做出响应时写入文件，例如错误日志，二进制日志文件，慢查询日志，查询日志等。

  

错误日志

  

MYSQL启动，运行，关闭过程的记录

  

show variables like'log_error' 定位文件

  

二进制日志文件

  

记录对MySQL数据库执行更改的所有操作。但是不包含select和show操作，因为这类操作本身没有对数据库进行修改。

  

~~~
mysql> update sample_math set m = 550 where m = 500;

Query OK, 1 row affected (0.01 sec)

Rows matched: 1 Changed: 1 Warnings: 0
~~~

  

mysql> show master status\G;

*************************** 1. row ***************************

 File: binlog.000018

 Position: 468

 Binlog_Do_DB:

 Binlog_Ignore_DB:

Executed_Gtid_Set:

1 row in set (0.00 sec)

  

mysql> show binlog events in 'binlog.000018'\G;

*************************** 1. row ***************************

 Log_name: binlog.000018

 Pos: 4

 Event_type: Format_desc

 Server_id: 1

End_log_pos: 124

 Info: Server ver: 8.0.16, Binlog ver: 4

*************************** 2. row ***************************

 Log_name: binlog.000018

 Pos: 124

 Event_type: Previous_gtids

 Server_id: 1

End_log_pos: 155

 Info:

*************************** 3. row ***************************

 Log_name: binlog.000018

 Pos: 155

 Event_type: Anonymous_Gtid

 Server_id: 1

End_log_pos: 234

 Info: SET @@SESSION.GTID_NEXT= 'ANONYMOUS'

*************************** 4. row ***************************

 Log_name: binlog.000018

 Pos: 234

 Event_type: Query

 Server_id: 1

End_log_pos: 318

 Info: BEGIN

*************************** 5. row ***************************

 Log_name: binlog.000018

 Pos: 318

 Event_type: Table_map

 Server_id: 1

End_log_pos: 379

 Info: table_id: 94 (shop.sample_math)

*************************** 6. row ***************************

 Log_name: binlog.000018

 Pos: 379

 Event_type: Update_rows

 Server_id: 1

End_log_pos: 437

 Info: table_id: 94 flags: STMT_END_F

*************************** 7. row ***************************

 Log_name: binlog.000018

 Pos: 437

 Event_type: Xid

 Server_id: 1

End_log_pos: 468

 Info: COMMIT /* xid=56 */

7 rows in set (0.00 sec)

  

如果用户需要记录select和show操作，只能使用查询日志。

  

二进制文件的用途

  

恢复，point-in-time恢复。

  

复制，通过复制二进制文件，使得远程数据库与本地数据库同步。

  

审计，通过二进制文件查看，判断是否有注入攻击。

  

配置 log-bin[name]启动二进制文件。

  

慢查询日志（用户手动开启）

  

帮助定位可能存在问题的SQL语句，从而进行SQL语句层面的优化。

  

通过 show variables like 'long_query_time'\G; 查看时间阀制

  

通过 show variables like 'log_slow_queries'\G; 查看慢查询日志启动情况。

  

show variables like 'log_queries_not_using_indexes'\G; 如果运行的SQL语句没有使用索引，则MySQL同样会将这条语句记录到慢查询日志文件。

  

show variables like 'log_throttle_queries_not_using_indexes'\G; 表示每分钟允许记录到slow log的且未使用索引的SQL次数。

  

查询日志

  

记录了所有对MySQL数据库请求的信息。无论是否被执行。

  

set global general_log = on; 开启log

  

show variables like 'general_log_file'; 定位文件

  

tail -f /usr/local/var/mysql/INdeMacBook-Pro.log 查看

  

#### socket文件

  

unix域套字节方式连接时需要的文件。

  

mysql> show variables like'socket'\G;

  

#### pid文件

  

MySQL实例的进程文件。

  

mysql> show variables like 'pid_file'\G;

  

#### MySQL表结构文件

  

存放MySQL表结构定义文件。

  

MySQL数据的存储是根据表进行的，不论是什么引擎，都会以frm文件进行记录。

  

#### InnoDB存储引擎文件

  

存储引擎独有的记录和索引。

  

表空间文件

  

InnoDB采用将存储的数据按照表空间（tablespace）进行存放的设计。默认初始大小为10MB，名为ibdata1。

  

重做日志文件

  

id_logfile0和id_logfile1
