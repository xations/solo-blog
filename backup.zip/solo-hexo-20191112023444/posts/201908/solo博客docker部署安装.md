title: solo博客docker部署安装
date: '2019-08-27 23:12:40'
updated: '2019-08-27 23:13:32'
tags: [solo, 博客]
permalink: /articles/2019/08/27/1566918760376.html
---
![neonbrand-3GZNPBLImWc-unsplash.jpg](https://i.loli.net/2019/08/27/NXs1JpmkeVvnlUa.jpg)
  

# 前言

  

为自己solo博客安装做个备份，只有solo使用docker，数据库和nginx单独安装。

  

## 准备

  

1.服务器 VPS （本文CentOS）

2.域名 （国内国外皆可，推荐[namesilo](https://www.namesilo.com/)）

3.域名解析

4.SSH到服务器 (建议修改22端口)

  

# 正文

  

## 安装

### 安装mysql数据库

```
yum install mariadb mariadb-server # centos7下叫mariadb, 用法与mysql一致
systemctl start mariadb #启动mariadb
systemctl enable mariadb #设置开机自启动
mysql_secure_installation #设置root密码等相关
```

例如用户名root 密码 password

  

### 安装nginx

  

配置repo

```
vi /etc/yum.repos.d/nginx.repo
```

安装nginx
```
 yum -y install nginx
 systemctl enable nginx
```
配置之前记得申请ssl,可以走https。

SSH上传ssl证书
```
scp <本地文件名> <用户名>@<ssh服务器地址>:<上传保存路径即文件名>
```
like
```
scp 2700738_amdyes.top.pem root@1.2.3.4:etc/nginx/ssl/
scp 2700738_amdyes.top.key root@1.2.3.4:etc/nginx/ssl/
```

配置 default.conf

```
vim /etc/nginx/conf.d/default.conf
```

```
server {
listen 443;
server_name localhost;

ssl on;

  

#charset koi8-r;

#access_log /var/log/nginx/host.access.log main;

  

ssl_certificate /ssl/2700738_amdyes.top.pem; # ssl 证书目录

ssl_certificate_key /ssl/2700738_amdyes.top.key;

ssl_session_timeout 5m;

ssl_protocols TLSv1 TLSv1.1 TLSv1.2;

ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;

ssl_prefer_server_ciphers on;

  

location / {

proxy_pass http://www.amdyes.top:8080;

}

# ......

}

server{

listen 80;

server_name localhost;

rewrite ^(.*) https://$host$1 permanent;

}

```

  

### 安装 docker

```
yum -y install docker
service docker start
docker run hello-world
```
出现 hello world 就证明安装正常了

### Docker 部署

获取最新镜像：
```
docker pull b3log/solo
```
使用 MySQL

先手动建库（库名 solo，字符集使用 utf8mb4，排序规则 utf8mb4_general_ci），

```
CREATE DATABASE `solo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

然后启动容器：

```
docker run --detach --name solo --network=host \

--env RUNTIME_DB="MYSQL" \

--env JDBC_USERNAME="root" \

--env JDBC_PASSWORD="password" \

--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \

--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \

b3log/solo --listen_port=8080 --server_scheme=https --server_host=amdyes.top --server_port=
```

```
docker ps
```

查看 solo 是否启动

没有则

```
docker logs -f -t --tail 10 solo
```
实时查看docker容器名为solo的最后10行日志

## 后记

挂载自定义皮肤 skins文件夹记得放置默认皮肤Pinghsu
